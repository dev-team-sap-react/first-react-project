import React from "react";
export default function Home() {
  return (
    <div>
      <h1>Error 404: Not Found</h1>
    </div>
  );
}
