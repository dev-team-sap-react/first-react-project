import React from "react";
import "./home.css";
export default function Home() {
  return (
    <div>
      <h1>Consulting People GmbH</h1>
    </div>
  );
}
